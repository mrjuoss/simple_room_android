package com.mrjuoss.lifecycleawaredemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String TAG = this.getClass().getSimpleName();
    private String mRandomNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(TAG, "Owner ON_CREATE");
        getLifecycle().addObserver(new MainActivityObserver());

        MainActivityViewModel model = ViewModelProviders.of(this).get(MainActivityViewModel.class);
        LiveData<String> number = model.getNumber();
        final TextView txtRandomNumber = findViewById(R.id.txt_random_number);
//        String number = getRandomNumber();
        number.observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                txtRandomNumber.setText(s);
            }
        });

        Button btnFetchData = findViewById(R.id.btn_fetch_data);
        btnFetchData.setOnClickListener(this);

    }

    private String getRandomNumber() {
        Log.i(TAG, "Get Random Number");
        if (mRandomNumber == null) {
            createRandomNumber();
        }
        return mRandomNumber;
    }

    private void createRandomNumber() {
        Log.i(TAG, "Create New Random Number");
        Random random = new Random();
        mRandomNumber = "Number " + (random.nextInt(10 - 1) + 1);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "Owner ON_START");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "Owner ON_STOP");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "Owner ON_DESTROY");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "Owner ON_PAUSE");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "Owner ON_RESUME");
    }

    @Override
    public void onClick(View v) {
        MainActivityViewModel model = ViewModelProviders.of(this).get(MainActivityViewModel.class);
        model.createRandomNumber();
    }
}
